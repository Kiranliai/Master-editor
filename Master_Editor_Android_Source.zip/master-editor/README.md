# Master Editor — Android MVP

An offline-first, mobile-first typography and graphic editor implemented as a self-contained HTML5 canvas app inside a native Android WebView. The product scope follows the supplied Master Editor PRD. The source is intentionally dependency-light: the editor itself does not call a network service or use a remote JavaScript library.

## Included in this MVP

- Canvas presets: 1:1 square, 16:9 thumbnail, 9:16 story/reel, 3:1 banner, 4:5 portrait, and custom dimensions up to 4096 × 4096 px.
- Multi-layer canvas with text, shapes, and imported images; tap to select and drag to reposition.
- Typography controls: local font family choices, custom font import (TTF/OTF/WOFF/WOFF2), fill and gradient fill, line-height, letter spacing, stroke, shadow, background pill/ribbon, and basic 3D extrusion.
- A procedural 32-shape catalog with fill, gradient, outline, dashed outline, and extrusion controls.
- Image controls: brightness, contrast, saturation, blur, opacity, shape clipping, and an outline effect.
- Background studio: solid colors, gradient colors, and transparency.
- Layer drawer: visibility, lock, opacity, blend mode, ordering, duplicate, delete, and numeric geometry.
- Undo/redo history (up to 40 states), editable `.mep` JSON project save/open, plus PNG/JPG/WebP/SVG/PDF export.
- PNG pHYs and JPEG JFIF density metadata injection for DPI-aware raster exports; PDF physical page dimensions are calculated using the selected DPI.
- Android image picker and native save to `Downloads/MasterEditor/` through a JavaScript bridge.
- A separate hostable PWA build in `web/`, including a basic service worker for offline caching.

## Build the Android app

### Automated build (recommended)

1. Create a GitHub repository and push the contents of this folder to the `main` or `master` branch.
2. Open **Actions → Build Master Editor APK → Run workflow** (or let the workflow run on push).
3. Download the `master-editor-debug-apk` artifact from the successful workflow run.
4. Install the debug APK on an Android 10+ device. Android may ask you to allow installs from the app used to open the APK.

The workflow uses Java 17, Gradle 8.7, Android Gradle Plugin 8.5.2, compile SDK 34, target SDK 34, and min SDK 29.

### Local build

Install Android Studio / Android SDK 34 and Gradle 8.7, then from this folder run:

```bash
gradle --no-daemon :app:assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk` (Gradle may append `.debug` to the application ID, not the APK filename).

## Run the PWA

Host the `web/` folder on any static HTTPS host. Open its URL in Chrome on Android and choose **Add to Home screen**. Service workers require a secure origin (HTTPS or localhost); simply opening `index.html` as a local file will not register offline caching.

## Important MVP boundaries

This is a working starter implementation, not a claim that every PRD feature is complete. The MVP does not yet include the Bezier node editor, mesh/wrap text, circular arc text, full perspective controls, a mathematically exact alpha-boundary sticker generator, CMYK separation, a PDF multi-page builder, a `.plb` legacy importer, cloud collaboration, or a signed production release. SVG serialization currently prioritizes common shapes/text/images; not all of the canvas catalog has an exact SVG path equivalent. The `.mep` format is readable UTF-8 JSON and stores embedded assets as data URLs. Native Android output is a debug build until a release keystore is configured.

## Folder map

- `app/src/main/assets/index.html` — the editor embedded in the Android app.
- `app/src/main/java/com/mastereditor/app/MainActivity.java` — Android WebView, file picker, native save bridge, and haptic bridge.
- `app/src/main/AndroidManifest.xml` — launcher activity and project file association intent filters.
- `app/src/main/res/mipmap-*` — app launcher icon in Android density sizes.
- `web/` — hostable PWA copy.
- `.github/workflows/build-apk.yml` — automated debug APK build.
