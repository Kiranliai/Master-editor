package com.mastereditor.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.database.Cursor;
import android.content.ContentResolver;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Base64;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1042;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(android.graphics.Color.rgb(16, 20, 30));
        window.setNavigationBarColor(android.graphics.Color.rgb(16, 20, 30));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.getAttributes().layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 20, 30));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent;
                try { intent = params.createIntent(); }
                catch (Exception e) { filePathCallback = null; return false; }
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("(function(){var s=document.getElementById('sheetBackdrop');if(s&&!s.classList.contains('hidden')){s.classList.add('hidden');return 'closed'}return 'none'})()", value -> {
                if ("\"none\"".equals(value)) MainActivity.super.onBackPressed();
            });
        } else super.onBackPressed();
    }

    private class AndroidBridge {
        @JavascriptInterface public void saveBase64File(String filename, String base64, String mimeType) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saving " + filename + "…", Toast.LENGTH_SHORT).show());
            OutputStream output = null;
            Uri uri = null;
            try {
                byte[] bytes = Base64.getDecoder().decode(base64);
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, sanitize(filename));
                values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MasterEditor");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                ContentResolver resolver = getContentResolver();
                uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IOException("Android could not create the Downloads file");
                output = resolver.openOutputStream(uri);
                if (output == null) throw new IOException("Android could not open the output file");
                output.write(bytes);
                output.flush();
                output.close(); output = null;
                ContentValues ready = new ContentValues(); ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(uri, ready, null, null);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved to Downloads/MasterEditor", Toast.LENGTH_LONG).show());
                try { webView.evaluateJavascript("window.__masterEditorSaveDone && window.__masterEditorSaveDone(true)", null); } catch (Exception ignored) {}
            } catch (Exception e) {
                if (output != null) try { output.close(); } catch (IOException ignored) {}
                final String message = e.getMessage() == null ? "Could not save file" : e.getMessage();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Save failed: " + message, Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface public void vibrate(int milliseconds) {
            try {
                android.os.Vibrator v = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v != null && v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) v.vibrate(android.os.VibrationEffect.createOneShot(Math.min(100, Math.max(1, milliseconds)), android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                    else v.vibrate(Math.min(100, Math.max(1, milliseconds)));
                }
            } catch (Exception ignored) {}
        }
    }

    private String sanitize(String name) {
        if (name == null || name.trim().isEmpty()) return "master-editor-export";
        return name.replaceAll("[/\\\\\\p{Cntrl}]", "-");
    }
}
